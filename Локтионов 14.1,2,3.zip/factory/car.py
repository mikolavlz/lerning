
class Car:
    def __init__(self,title,price):
        self.title = title
        self.price = price

