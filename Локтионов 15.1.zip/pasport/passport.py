class Pasport:
    def __init__(self, serial,number,fio):
        self.number = number
        self.serial = serial
        self.fio = fio


