class Category:
    def __init__(self,title):
        # self.id_category = id_category
        self.title = title